package com.example.hospitalinformationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class WelcomeActivity extends AppCompatActivity {
    private ImageView profileImage, reportsImage, servicesImage, appointmentImage, doctorsprofileImage, signoutImage, locationImage, aboutImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        profileImage = (ImageView) findViewById(R.id.profile);
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (WelcomeActivity.this,ProfileActivity.class);
                startActivity(intent);
            }
        });

        reportsImage = (ImageView) findViewById(R.id.reports);
        reportsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (WelcomeActivity.this,ReportsActivity.class);
                startActivity(intent);
            }
        });

        servicesImage = (ImageView)findViewById(R.id.services);
        servicesImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this,ServicesActivity.class);
                startActivity(intent);
            }
        });

        appointmentImage = (ImageView)findViewById(R.id.book_appointment);
        appointmentImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this,AppointmentActivity.class);
                startActivity(intent);
            }
        });

        doctorsprofileImage = (ImageView)findViewById(R.id.doctors_profile);
        doctorsprofileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this,DoctorsprofileActivity.class);
                startActivity(intent);
            }
        });

        locationImage = (ImageView) findViewById(R.id.location);
        locationImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (WelcomeActivity.this,MapsActivity.class);
                startActivity(intent);
            }
        });

        aboutImage = (ImageView) findViewById(R.id.about);
        aboutImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (WelcomeActivity.this,AboutActivity.class);
                startActivity(intent);
            }
        });

        signoutImage = (ImageView) findViewById(R.id.sign_out);
        signoutImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (WelcomeActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
