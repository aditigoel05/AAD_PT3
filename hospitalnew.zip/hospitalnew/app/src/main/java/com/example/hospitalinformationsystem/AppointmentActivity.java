package com.example.hospitalinformationsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AppointmentActivity extends AppCompatActivity {
    Button doctor,confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        doctor = (Button) findViewById(R.id.doctor_button);
        confirm = (Button) findViewById(R.id.confirm);
        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AppointmentActivity.this,DoctorsprofileActivity.class);
                startActivity(intent);
            }
        });
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AppointmentActivity.this, "Appointment booked", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void showDatePicker(View view){
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(),"datepicker");
    }
    public void processDatePickerResult(int year,int month,int day){
        String month_string = Integer.toString(month+1);
        String day_string = Integer.toString(day);
        String year_string = Integer.toString(year);
        String dateMessage = (day_string+"/"+month_string+"/"+year_string);
        Toast.makeText(this,"Date:" + dateMessage,Toast.LENGTH_SHORT).show();
    }
    public void showTimePicker(View view){
        TimePickerFragment myFragment = new TimePickerFragment();
        myFragment.show(getSupportFragmentManager(),"timepicker");
    }
    public void processTimePickerResult(int hourofday,int minute){
        String hour_string = Integer.toString(hourofday);
        String minute_string = Integer.toString(minute);
        String timeMessage = (hour_string+":"+minute_string);
        Toast.makeText(this,"Time:" + timeMessage,Toast.LENGTH_SHORT).show();
    }
}
