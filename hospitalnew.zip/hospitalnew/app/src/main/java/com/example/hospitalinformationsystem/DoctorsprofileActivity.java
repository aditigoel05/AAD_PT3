package com.example.hospitalinformationsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class DoctorsprofileActivity extends AppCompatActivity implements View.OnClickListener {
    public CardView c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorsprofile);
        c1=(CardView) findViewById(R.id.c1);
        c2=(CardView) findViewById(R.id.c2);
        c3=(CardView) findViewById(R.id.c3);
        c4=(CardView) findViewById(R.id.c4);
        c5=(CardView) findViewById(R.id.c5);
        c6=(CardView) findViewById(R.id.c6);
        c7=(CardView) findViewById(R.id.c7);
        c8=(CardView) findViewById(R.id.c8);
        c9=(CardView) findViewById(R.id.c9);
        c10=(CardView) findViewById(R.id.c10);
        c11=(CardView) findViewById(R.id.c11);
        c12=(CardView) findViewById(R.id.c12);

        c1.setOnClickListener(this);
        c2.setOnClickListener(this);
        c3.setOnClickListener(this);
        c4.setOnClickListener(this);
        c5.setOnClickListener(this);
        c6.setOnClickListener(this);
        c7.setOnClickListener(this);
        c8.setOnClickListener(this);
        c9.setOnClickListener(this);
        c10.setOnClickListener(this);
        c11.setOnClickListener(this);
        c12.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(DoctorsprofileActivity.this,AppointmentActivity.class);
        startActivity(intent);
        switch (v.getId()){
            case R.id.c1:
                Toast.makeText(this,"Doctor: Dr. Amit Kumar"  ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c2:
                Toast.makeText(this,"Doctor: Dr. Ashish Chauhan" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c3:
                Toast.makeText(this,"Doctor: Dr. Nikita Malik" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c4:
                Toast.makeText(this,"Doctor: Dr. Mukesh Garg" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c5:
                Toast.makeText(this,"Doctor: Dr. Pankaj Dawar" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c6:
                Toast.makeText(this,"Doctor: Dr. Rakesh Gupta" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c7:
                Toast.makeText(this,"Doctor: Dr. Ritu Jha" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c8:
                Toast.makeText(this,"Doctor: Dr. Renu Gupta" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c9:
                Toast.makeText(this,"Doctor: Dr. Shruti Kholi" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c10:
                Toast.makeText(this,"Doctor: Dr. Sumit Narang" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c11:
                Toast.makeText(this,"Doctor: Dr. Sunil Rana" ,Toast.LENGTH_SHORT).show();
                break;
            case R.id.c12:
                Toast.makeText(this,"Doctor: Dr. Vivek Bansal" ,Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
